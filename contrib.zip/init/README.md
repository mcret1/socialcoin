Sample configuration files for:

SystemD: socialcoind.service
Upstart: socialcoind.conf
OpenRC:  socialcoind.openrc
         socialcoind.openrcconf
CentOS:  socialcoind.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
